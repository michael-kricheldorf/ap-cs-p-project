'''
Tile Dictionary:
        / = unavailable tile = 0
        " " = floor tile = 1
        # = wall tile = 2
        O = player = 3
        T = enemy = 4
'''

# imports
import random as r

class Display:
    def __init__(self, m):
        displayWindow = [[" " for col in range(7)] for row in range(7)]
        
    def updateDisplay(self, m):
        self.m = m
        for row in range(len(self.m)):
            for col in range(len(self.m[0])):
                if self.m[row][col] == 3:
                    
        
    def printDisplay(self):