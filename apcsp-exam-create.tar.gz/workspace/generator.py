# imports
import random as r
import math as m
import player as pl
import enemy as en
import loot as lt

class Map:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.dirValues = [
            [-1, 0], # north, 0
            [0, 1], # east, 1
            [1, 0], # south, 2
            [0, -1]] # west, 3
        
        self.m = [[0 for col in range(width)] for row in range(height)]
        
    def setupMap(self):
        # creates the floors
        spawnPos = [int(self.width / 2), int(self.height / 2)]
        floorQuota = int(self.width * self.height / 5)
        oldFloorPos = spawnPos
        
        isDone = False
        
        while not isDone:
            numberFloors = 0
            newFloorPos = self.walker(oldFloorPos)
            
            # is it within a #-tile boundary of the edge of the array (BUG PREVENTION)
            if newFloorPos[0] > len(self.m[0]) - 5 or newFloorPos[1] > len(self.m) - 5 or newFloorPos[0] < 4 or newFloorPos[1] < 4:
                continue
            
            oldFloorPos = newFloorPos
            self.m[newFloorPos[0]][newFloorPos[1]] = 1
            
            for row in range(len(self.m)):
                for col in range(len(self.m[0])):
                    if self.m[row][col]:
                        numberFloors += 1
        
            if numberFloors > floorQuota:
                isDone = True
        
        # creates the walls
        for row in range(len(self.m)):
            for col in range(len(self.m[0])):
                if row < len(self.m) and col < len(self.m[0]) and row > 0 and col > 0:
                    if self.m[row][col] == 1:
                        if not self.m[row - 1][col]:
                            self.m[row - 1][col] = 2
                            
                        if not self.m[row][col - 1]:
                            self.m[row][col - 1] = 2
                            
                        if not self.m[row + 1][col]:
                            self.m[row + 1][col] = 2
                            
                        if not self.m[row][col + 1]:
                            self.m[row][col + 1] = 2
                    elif self.m[row][col] == 0:
                        self.m[row][col] = 0
                        
                        
        # destroys individual, lonely, walls
        for row in range(len(self.m)):
            for col in range(len(self.m[0])):
                if row < len(self.m) - 1 and col < len(self.m[0]) - 1 and row > 1 and col > 1:
                    if self.m[row][col] == 2:
                        if self.m[row - 1][col] == 1 and self.m[row][col + 1] == 1 and self.m[row + 1][col] == 1 and self.m[row][col - 1] == 1:
                            self.m[row][col] = 1
        
    def spawnEnemies(self, enemyQuota):
        # if random chance then spawn an enemy, as long as it meets certain quota
        isDone = False
        self.enemyList = []
        while not isDone:
            for row in range(len(self.m)):
                for col in range(len(self.m[0])):
                    if self.m[row][col] == 1:
                        spawnRand = r.randrange(100)
                        if spawnRand == 0:
                            self.enemy = en.Enemy(row, col)
                            self.enemyList.append(self.enemy)
                            self.m[self.enemy.draw()[0]][self.enemy.draw()[1]] = self.enemy.draw()[4]
                    if len(self.enemyList) >= enemyQuota:
                        isDone = True
                        break
                if isDone:
                    break
        
        return self.enemyList
        
    def spawnPlayer(self):
        isDone = False
        countPlayer = 0
        
        # randomly spawns player in a map, randomly out of 1/50 chance, if only one enemy is within 3 spaces, and if the spawnpoint is on a floor tile
        while not isDone:
            for row in range(len(self.m)):
                for col in range(len(self.m[0])):
                    if self.m[row][col] == 1:
                        random = r.randrange(99)
                        if random == 1:
                            countEnemies = 0
                            for tempRow in range(row - 3, row + 4):
                                for tempCol in range(col - 3, col + 4):
                                    if self.m[tempRow][tempCol] == 4:
                                        countEnemies += 1
                            if countEnemies == 1:
                                self.player = pl.Player(row, col)
                                self.m[self.player.draw()[0]][self.player.draw()[1]] = self.player.draw()[2]
                                countPlayer += 1
                    
                    if countPlayer == 1:
                        isDone = True
                        break
                if isDone:
                    break
                
        return self.player
                
    def spawnLoot(self, lootQuota):
        # spawns loot randomly, some based on player position
        isDone = False
        lootNumber = 0
        
        while not isDone:
            for row in range(len(self.m)):
                for col in range(len(self.m[0])):
                    if self.m[row][col] == 1:
                        random = r.randrange(100)
                        if random == 1:
                            self.m[row][col] = 5
                            lootNumber += 1
                            
                    if lootNumber >= lootQuota:
                        isDone = True
                        break
                if isDone:
                    break
                
    def updateMap(self):
        for enemy in self.enemyList:
            self.m[enemy.draw()[0]][enemy.draw()[1]] = enemy.draw()[4]
            self.m[enemy.draw()[2]][enemy.draw()[3]] = 1
    
    def walker(self, oldCoords):
        # adds up the two list values returned from zip, resulting in a new position
        newCoords = list(map(sum, zip(oldCoords, self.randDir())))
        
        return newCoords
    
    def randDir(self):
        # random num from 0 to 3, direction is returned based on num
        # 0 = north, 1 = east, 2 = south, 3 = west
        random = r.randrange(4)
        
        if random == 0:
            direction = [0, 1]
        elif random == 1:
            direction = [1, 0]
        elif random == 2:
            direction = [0, -1]
        elif random == 3:
            direction = [-1, 0]
        
        return direction
        