'''
AP COMPUTER SCIENCE PRINCIPLES "CREATE" EXAM - CODE

Functional Title

Resources Used: 
    Nuclear Throne Procedural Generation: https://github.com/wbeaty/ProceduralGenerationOfNuclearThrone
    
Game Information:
    Tile Dictionary:
        / = unavailable tile = 0
        " " = floor tile = 1
        # = wall tile = 2
        O = player = 3
        T = enemy = 4
        * = loot object = 5
'''

# imports
import random as r
import math as m
import generator as g
import player as pl
# import display as dp

# functions
    # init map
grid = g.Map(64, 64)
# create floors and walls
grid.setupMap()
# create enemies
enemyList = grid.spawnEnemies(40)
# add player object
player = grid.spawnPlayer()
# add loot
lootList = grid.spawnLoot(20)

# set m equal to grid object's m, then return it
m = grid.m


# test script


print("\n")

newM = [[" " for col in range(len(m[0]))] for row in range(len(m))]
  
  
for row in range(len(newM)):
    for col in range(len(newM[0])):
        if m[row][col] == 0:
            newM[row][col] = "/"
        elif m[row][col] == 1:
            newM[row][col] = " "
        elif m[row][col] == 2:
            newM[row][col] = "#"
        elif m[row][col] == 3:
            newM[row][col] = "O"
        elif m[row][col] == 4:
            newM[row][col] = "T"
        elif m[row][col] == 5:
            newM[row][col] = "*"
            
for row in newM:
    print(' '.join([str(col) for col in row]))
    
print('\n')

for enemy in enemyList:
    enemy.updateCoords(0)
    
grid.updateMap()

for row in range(len(newM)):
    for col in range(len(newM[0])):
        if m[row][col] == 0:
            newM[row][col] = "/"
        elif m[row][col] == 1:
            newM[row][col] = " "
        elif m[row][col] == 2:
            newM[row][col] = "#"
        elif m[row][col] == 3:
            newM[row][col] = "O"
        elif m[row][col] == 4:
            newM[row][col] = "T"
        elif m[row][col] == 5:
            newM[row][col] = "*"
            
for row in newM:
    print(' '.join([str(col) for col in row]))