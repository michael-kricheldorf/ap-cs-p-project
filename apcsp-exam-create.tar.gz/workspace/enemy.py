# imports
import random as r

class Enemy:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.ATK = 0
        self.DEF = 0
        self.HP = 0
        self.tileID = 4
    
    def updateCoords(self, dirNum):
        # update enemy coordinates
        self.updateDirection(dirNum)
        
        self.x = list(map(sum, zip([self.x, self.y], self.direction)))[0] # check this in IDLE
        self.y = list(map(sum, zip([self.x, self.y], self.direction)))[1]
        
        playerCoords = [self.x, self.y]
        return playerCoords
        
    '''this whole class needs to be edited'''
    def attack(self, playerPos): 
        # return enemy attack direction
        
        
        attackX = list(map(sum, zip([self.x, self.y], self.direction)))[0] # check this in IDLE
        attackY = list(map(sum, zip([self.x, self.y], self.direction)))[1]
        
        attackData = [attackX, attackY, self.ATK]
        return attackData
        
    def draw(self):
        return [self.x, self.y, self.tileID]
    
    def updateDirection(self, dirNum):
        # updates player direction
        if dirNum == 0:
            self.direction = [0, 1]
        elif dirNum == 1:
            self.direction = [1, 0]
        elif dirNum == 2:
            self.direction = [0, -1]
        elif dirNum == 3:
            self.direction = [-1, 0]
        