# imports
import random as r